<?php
// LIMA Solutions ERP - Reports API Router V1

require_once '../../../admin/auth.php';
require_once '../../../admin/modules_helper.php';
require_once '../../../modules/reports/model/Report.php';
require_once '../../../modules/reports/controller/ReportController.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$companyId = getActiveCompanyId();
if (!$companyId) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Aucune entreprise active sélectionnée.']);
    exit();
}

$userRole = $_SESSION['user_role'] ?? 'viewer';

// Enforce access control for the 'reports' module
enforceModuleAccess('reports', $userRole, $companyId, 'view', $pdo);

$reportModel = new Report($pdo);
$controller = new ReportController($reportModel);

$filters = $controller->parseFilters($_GET);
$action = $_GET['action'] ?? 'kpis';
$exportFormat = $_GET['export'] ?? '';

// Fetch company details for PDF template headers
$stmtComp = $pdo->prepare("SELECT * FROM companies WHERE id = :id LIMIT 1");
$stmtComp->execute(['id' => $companyId]);
$company = $stmtComp->fetch();

try {
    $reportData = null;
    $reportTitle = "";
    
    // Process Actions
    switch ($action) {
        case 'kpis':
            $reportData = $reportModel->getKPIs($companyId, $filters);
            $reportTitle = "Tableau de Bord Exécutif - KPIs";
            break;
            
        case 'cashflow':
            $groupType = $_GET['group_type'] ?? 'month';
            if (!in_array($groupType, ['day', 'week', 'month', 'year'])) {
                $groupType = 'month';
            }
            $reportData = $reportModel->getCashFlow($companyId, $groupType, $filters);
            $reportTitle = "Flux de Trésorerie (Cash Flow)";
            break;
            
        case 'receivables':
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
            if ($page < 1) $page = 1;
            if ($limit < 1 || $limit > 200) $limit = 50;
            $offset = ($page - 1) * $limit;
            
            $rawList = $reportModel->getReceivables($companyId, $filters, $limit, $offset);
            $totalRecords = $reportModel->getReceivablesCount($companyId, $filters);
            $summary = $reportModel->getReceivablesSummary($companyId, $filters);
            
            // Format response
            $reportData = [
                'list' => $rawList,
                'summary' => $summary,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total_records' => $totalRecords,
                    'total_pages' => ceil($totalRecords / $limit)
                ]
            ];
            $reportTitle = "Comptes Clients à Recevoir";
            break;
            
        case 'tax':
            $reportData = $reportModel->getTaxReport($companyId, $filters);
            $reportTitle = "Rapport Fiscalité - Déclaration de TVA";
            break;
            
        case 'customers':
            $reportData = $reportModel->getCustomersReport($companyId, $filters);
            $reportTitle = "Analyse et Classement des Clients";
            break;
            
        case 'quotes':
            $reportData = $reportModel->getQuotesReport($companyId, $filters);
            $reportTitle = "Performance et Conversion des Devis";
            break;
            
        case 'payments':
            $reportData = $reportModel->getPaymentsReport($companyId, $filters);
            $reportTitle = "Règlements par Méthodes de Paiement";
            break;

        case 'hours_by_project':
            $reportData = $reportModel->getHoursByProject($companyId, $filters);
            $reportTitle = "Heures par Projet";
            break;

        case 'hours_by_worker':
            $reportData = $reportModel->getHoursByWorker($companyId, $filters);
            $reportTitle = "Heures par Collaborateur";
            break;

        case 'estimated_vs_realized':
            $reportData = $reportModel->getEstimatedVsRealized($companyId);
            $reportTitle = "Heures Estimées vs Réalisées";
            break;

        case 'project_profitability':
            $reportData = $reportModel->getProjectProfitability($companyId);
            $reportTitle = "Rentabilité des Projets";
            break;

        case 'billing_reconciliation':
            $reportData = $reportModel->getReconciliation($companyId, $filters);
            $reportTitle = "Réconciliation de Facturation et Marges";
            break;

            
        default:
            http_response_code(400);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => "Action de rapport non valide."]);
            exit();
    }

    // 1. Audit Logs Registry for Sensitive Queries and Exports
    $reqId = bin2hex(random_bytes(16));
    $logAction = ($exportFormat ? 'Exported ' : 'Queried ') . $action . ' report';
    $logData = [
        'user_id' => $_SESSION['user_id'],
        'report' => $action,
        'filters' => $filters,
        'format' => $exportFormat ?: 'JSON',
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Write in activity logs
    logActivity($_SESSION['user_id'], $companyId, 'reports', 'reports', 0, $logAction, $pdo, null, $logData, $reqId);

    // 2. Export Handling
    if (!empty($exportFormat)) {
        // We prepare tabular datasets representing each sub-report for Excel/CSV/PDF exports
        $exportData = [];
        $headers = [];
        
        switch ($action) {
            case 'kpis':
                $headers = ['Indicateur', 'Valeur'];
                $exportData = [
                    ['Indicateur' => 'Receita hoje', 'Valeur' => $reportData['revenue_today']],
                    ['Indicateur' => 'Receita este mês', 'Valeur' => $reportData['revenue_month']],
                    ['Indicateur' => 'Receita este ano', 'Valeur' => $reportData['revenue_year']],
                    ['Indicateur' => 'Total faturado', 'Valeur' => $reportData['total_billed']],
                    ['Indicateur' => 'Total recebido', 'Valeur' => $reportData['total_received']],
                    ['Indicateur' => 'Saldo pendente', 'Valeur' => $reportData['total_pending']],
                    ['Indicateur' => 'Valor estornado', 'Valeur' => $reportData['total_reversed']],
                    ['Indicateur' => 'Clientes ativos', 'Valeur' => $reportData['clients_active']],
                    ['Indicateur' => 'Novos clientes', 'Valeur' => $reportData['clients_new']],
                    ['Indicateur' => 'Faturas emitidas', 'Valeur' => $reportData['invoices_count']],
                    ['Indicateur' => 'Orçamentos emitidos', 'Valeur' => $reportData['quotes_count']],
                    ['Indicateur' => 'Taxa de conversão (%)', 'Valeur' => $reportData['conversion_rate']],
                    ['Indicateur' => 'Ticket médio', 'Valeur' => $reportData['ticket_average']],
                    ['Indicateur' => 'LTV médio', 'Valeur' => $reportData['ltv_average']],
                ];
                break;
                
            case 'cashflow':
                $headers = ['Période', 'Entrées (Cash In)', 'Sorties (Cash Out)', 'Solde Net (Net Cash)'];
                foreach ($reportData as $row) {
                    $exportData[] = [
                        'Période' => $row['period'],
                        'Entrées (Cash In)' => $row['cash_in'],
                        'Sorties (Cash Out)' => $row['cash_out'],
                        'Solde Net (Net Cash)' => $row['net_cash']
                    ];
                }
                break;
                
            case 'receivables':
                $headers = ['Client', 'Facture', 'Échéance', 'Montant Total', 'Montant Payé', 'Solde Restant', 'Jours de Retard'];
                $list = $reportData['list'] ?? [];
                foreach ($list as $row) {
                    $exportData[] = [
                        'Client' => $row['client_name'] . ($row['client_company'] ? ' (' . $row['client_company'] . ')' : ''),
                        'Facture' => $row['invoice_number'],
                        'Échéance' => $row['due_date'],
                        'Montant Total' => $row['total'] . ' ' . $row['currency'],
                        'Montant Payé' => $row['paid_amount'] . ' ' . $row['currency'],
                        'Solde Restant' => $row['balance_due'] . ' ' . $row['currency'],
                        'Jours de Retard' => $row['days_overdue']
                    ];
                }
                break;
                
            case 'tax':
                $headers = ['Rapport TVA', 'Base Subtotal', 'Montant TVA', 'Total Général'];
                // Conjoin elements
                $rates = $reportData['by_rate'] ?? [];
                foreach ($rates as $row) {
                    $exportData[] = [
                        'Rapport TVA' => 'TVA Rate: ' . $row['tax_name'] . ' (' . $row['tax_rate'] . '%)',
                        'Base Subtotal' => $row['subtotal'],
                        'Montant TVA' => $row['tax_amount'],
                        'Total Général' => $row['total']
                    ];
                }
                break;
                
            case 'customers':
                $headers = ['Client', 'Faturamento Total', 'Paiements Reçus (LTV)', 'Factures Émises', 'Devis Émis', 'Statut'];
                foreach ($reportData as $row) {
                    $exportData[] = [
                        'Client' => $row['name'] . ($row['company'] ? ' (' . $row['company'] . ')' : ''),
                        'Faturamento Total' => $row['total_billed'],
                        'Paiements Reçus (LTV)' => $row['ltv'],
                        'Factures Émises' => $row['invoices_count'],
                        'Devis Émis' => $row['quotes_count'],
                        'Statut' => $row['active'] == 1 ? 'Actif' : 'Inactif'
                    ];
                }
                break;
                
            case 'quotes':
                $headers = ['Performance Devis', 'Métrique', 'Taux (%) / Jours'];
                $exportData = [
                    ['Performance Devis' => 'Total devis', 'Métrique' => 'Volume', 'Taux (%) / Jours' => $reportData['total_count']],
                    ['Performance Devis' => 'Devis acceptés', 'Métrique' => 'Volume', 'Taux (%) / Jours' => $reportData['accepted_count']],
                    ['Performance Devis' => 'Convertis en factures', 'Métrique' => 'Volume', 'Taux (%) / Jours' => $reportData['converted_count']],
                    ['Performance Devis' => 'Taux d\'acceptation', 'Métrique' => 'Pourcentage', 'Taux (%) / Jours' => $reportData['acceptance_rate'] . ' %'],
                    ['Performance Devis' => 'Taux de conversion', 'Métrique' => 'Pourcentage', 'Taux (%) / Jours' => $reportData['conversion_rate'] . ' %'],
                    ['Performance Devis' => 'Délai moyen de facturation', 'Métrique' => 'Jours', 'Taux (%) / Jours' => $reportData['avg_time_to_invoice'] . ' jours']
                ];
                break;
                
            case 'payments':
                $headers = ['Méthode de Paiement', 'Transactions (Qtd)', 'Montant Brut', 'Montant Extourné', 'Montant Net'];
                foreach ($reportData as $row) {
                    $exportData[] = [
                        'Méthode de Paiement' => $row['payment_method'],
                        'Transactions (Qtd)' => $row['quantity'],
                        'Montant Brut' => $row['gross_amount'],
                        'Montant Extourné' => $row['reversals'],
                        'Montant Net' => $row['net_amount']
                    ];
                }
                break;

            case 'billing_reconciliation':
                $headers = ['Code Projet', 'Nom Projet', 'Devise', 'H. Approuvées', 'H. Facturées', 'H. Pendantes', 'Revenu Facturé', 'Revenu Pendant', 'Revenu Total', 'Coût Total', 'Marge'];
                foreach ($reportData as $row) {
                    $exportData[] = [
                        'Code Projet' => $row['project_code'],
                        'Nom Projet' => $row['project_name'],
                        'Devise' => $row['currency'],
                        'H. Approuvées' => $row['approved_hours'],
                        'H. Facturées' => $row['invoiced_hours'],
                        'H. Pendantes' => $row['pending_hours'],
                        'Revenu Facturé' => $row['invoiced_revenue'],
                        'Revenu Pendant' => $row['pending_revenue'],
                        'Revenu Total' => $row['total_revenue'],
                        'Coût Total' => $row['total_cost'],
                        'Marge' => $row['margin']
                    ];
                }
                break;
        }


        // Trigger exports
        if ($exportFormat === 'csv') {
            $controller->exportCsv($action . '_report', $exportData);
        } elseif ($exportFormat === 'xlsx') {
            $controller->exportXlsx($action . '_report', $exportData);
        } elseif ($exportFormat === 'pdf') {
            // Unpack tabular rows into flat values for PDF template rendering
            $pdfRows = [];
            foreach ($exportData as $row) {
                $pdfRows[] = array_values($row);
            }
            $controller->exportPdf($reportTitle, $headers, $pdfRows, $company);
        }
    }

    // Default: Respond JSON
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => true,
        'message' => 'Rapport chargé avec succès.',
        'data' => $reportData
    ]);

} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
