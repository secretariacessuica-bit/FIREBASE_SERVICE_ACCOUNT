<?php
// LIMA Solutions ERP - CRM Clients API V1

require_once '../../../admin/auth.php';
require_once '../../../admin/modules_helper.php';
require_once '../../../admin/sequences_helper.php';
require_once '../../../admin/timeline_helper.php';
require_once '../../../modules/crm/model/Client.php';
require_once '../../../modules/crm/controller/ClientController.php';

header('Content-Type: application/json; charset=utf-8');

$companyId = getActiveCompanyId();
if (!$companyId) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Aucune entreprise active selectionnée.'
    ]);
    exit();
}

$userRole = $_SESSION['user_role'] ?? 'viewer';

// 1. Enforce Module Access (CRM)
enforceModuleAccess('crm', $userRole, $companyId, 'view', $pdo);

$clientModel = new Client($pdo);
$controller = new ClientController($clientModel);

$method = $_SERVER['REQUEST_METHOD'];

// Standardized CSRF Protection Check for mutating requests
if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    // Read JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    // Read CSRF Token from Header or Body
    $clientCsrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $input['csrf_token'] ?? '';
    $sessionCsrfToken = $_SESSION['csrf_token'] ?? '';

    if (empty($sessionCsrfToken) || empty($clientCsrfToken) || !hash_equals($sessionCsrfToken, $clientCsrfToken)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Erreur de sécurité CSRF: Requête rejetée.'
        ]);
        exit();
    }
} else {
    // For GET requests, we might parse query parameters
    $input = $_GET;
}

// GET Requests: List with pagination, Search with pagination, View single profile
if ($method === 'GET') {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    if ($page < 1) $page = 1;
    if ($limit < 1 || $limit > 200) $limit = 50;
    $offset = ($page - 1) * $limit;

    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        $client = $clientModel->getById($id, $companyId);
        if (!$client) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'Client non trouvé.'
            ]);
            exit();
        }
        echo json_encode([
            'success' => true,
            'message' => 'Profil client chargé.',
            'data' => ['client' => $client]
        ]);
        exit();
    } elseif (isset($_GET['search'])) {
        $term = trim($_GET['search']);
        $clients = $clientModel->search($term, $companyId, $limit, $offset);
        $total = $clientModel->getSearchCount($term, $companyId);
        
        echo json_encode([
            'success' => true,
            'message' => 'Résultats de la recherche.',
            'data' => [
                'clients' => $clients,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total_records' => $total,
                    'total_pages' => ceil($total / $limit)
                ]
            ]
        ]);
        exit();
    } else {
        $clients = $clientModel->getAll($companyId, $limit, $offset);
        $total = $clientModel->getTotalCount($companyId);
        
        echo json_encode([
            'success' => true,
            'message' => 'Liste des clients active.',
            'data' => [
                'clients' => $clients,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total_records' => $total,
                    'total_pages' => ceil($total / $limit)
                ]
            ]
        ]);
        exit();
    }
}

// Mutation Guard: Requires 'edit' permissions
if (!hasModulePermission($userRole, 'crm', 'edit', $pdo)) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => "Accès interdit: Droits d'écriture insuffisants pour le module CRM."
    ]);
    exit();
}

// POST: Create or Legacy wrapper for Update/Delete
if ($method === 'POST') {
    $action = $input['action'] ?? '';

    if ($action === 'delete') {
        $id = (int)($input['id'] ?? 0);
        if (!$id) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID client manquant.']);
            exit();
        }
        $oldClient = $clientModel->getById($id, $companyId);
        $result = $clientModel->deactivate($id, $companyId);
        if ($result) {
            // Log to Audit Trail with before data snapshot
            $reqId = bin2hex(random_bytes(16));
            logActivity($_SESSION['user_id'], $companyId, 'crm', 'clients', $id, 'Deactivated client ID ' . $id, $pdo, $oldClient, null, $reqId);
            
            // Log to Entity Timeline
            logEntityEvent($companyId, 'crm', 'clients', $id, 'deactivated', $_SESSION['user_id'], "Client désactivé (Soft Delete)", $pdo);

            echo json_encode([
                'success' => true,
                'message' => 'Client désactivé avec succès.'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Échec de la désactivation du client.']);
        }
        exit();
    } elseif ($action === 'update') {
        $id = (int)($input['id'] ?? 0);
        if (!$id) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID client manquant.']);
            exit();
        }
        $cleanData = $controller->sanitize($input);
        $errors = $controller->validate($cleanData, true);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }
        $oldClient = $clientModel->getById($id, $companyId);
        $cleanData = $controller->sanitize($input);
        $errors = $controller->validate($cleanData, true);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }
        $result = $clientModel->update($id, $cleanData, $companyId);
        if ($result) {
            $newClient = $clientModel->getById($id, $companyId);
            // Log to Audit Trail with snapshots and request ID
            $reqId = bin2hex(random_bytes(16));
            logActivity($_SESSION['user_id'], $companyId, 'crm', 'clients', $id, 'Updated client details for ID ' . $id, $pdo, $oldClient, $newClient, $reqId);

            // Log to Entity Timeline
            logEntityEvent($companyId, 'crm', 'clients', $id, 'updated', $_SESSION['user_id'], "Coordonnées du client mises à jour.", $pdo);

            echo json_encode([
                'success' => true,
                'message' => 'Client mis à jour avec succès.'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Échec de la mise à jour du client.']);
        }
        exit();
    } else {
        // Create client
        $cleanData = $controller->sanitize($input);
        
        // Auto generate customer code if empty (transaction-safe sequence generator)
        if (empty($cleanData['customer_code'])) {
            $cleanData['customer_code'] = generateSequence($companyId, 'CLI', $pdo);
        }

        $errors = $controller->validate($cleanData);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }

        $cleanData['company_id'] = $companyId;
        $clientId = $clientModel->create($cleanData);
        
        if ($clientId) {
            $newClient = $clientModel->getById($clientId, $companyId);
            // Log to Audit Trail with snapshots and request ID
            $reqId = bin2hex(random_bytes(16));
            logActivity($_SESSION['user_id'], $companyId, 'crm', 'clients', $clientId, 'Created new client: ' . $cleanData['customer_code'], $pdo, null, $newClient, $reqId);

            // Log to Entity Timeline
            logEntityEvent($companyId, 'crm', 'clients', $clientId, 'created', $_SESSION['user_id'], "Nouveau dossier client créé avec code " . $cleanData['customer_code'], $pdo);

            echo json_encode([
                'success' => true,
                'message' => 'Client créé avec succès.',
                'data' => [
                    'id' => $clientId,
                    'customer_code' => $cleanData['customer_code']
                ]
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Échec de la création du client.']);
        }
        exit();
    }
}
