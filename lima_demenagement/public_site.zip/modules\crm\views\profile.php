<?php
// LIMA Solutions ERP - CRM Client Profile View
require_once '../../../admin/auth.php';
require_once '../../../admin/modules_helper.php';

$companyId = getActiveCompanyId();
$userRole = $_SESSION['user_role'] ?? 'viewer';

// Enforce module access and permissions (Requires at least 'view' permission)
enforceModuleAccess('crm', $userRole, $companyId, 'view', $pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("Erreur: ID client invalide.");
}

// Fetch client details securely matching company_id
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = :id AND company_id = :company_id LIMIT 1");
$stmt->execute(['id' => $id, 'company_id' => $companyId]);
$client = $stmt->fetch();

if (!$client) {
    die("Erreur: Client non trouvé ou accès non autorisé.");
}

// Extract initials for avatar placeholder
$words = explode(' ', $client['name']);
$initials = '';
foreach ($words as $w) {
    $initials .= strtoupper(substr($w, 0, 1));
}
$initials = substr($initials, 0, 2);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Client - <?php echo htmlspecialchars($client['name']); ?> - LIMA Solutions</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome for clean icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Main styles styling from dashboard -->
    <link rel="stylesheet" href="../../admin/css/admin.css" onerror="this.onerror=null;this.href='../../../admin/index.php';">
    <style>
        :root {
            --primary-teal: #007a87;
            --primary-teal-dark: #005a63;
            --primary-teal-light: #e6f2f3;
            --sidebar-bg: #112224;
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
            --border-gray: #e2e8f0;
            --white: #ffffff;
            --bg-light: #f8fafc;
            --border-radius: 8px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Outfit', 'Arial', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            background-color: var(--sidebar-bg);
            color: var(--white);
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            flex-shrink: 0;
        }

        .sidebar-brand {
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-brand i {
            font-size: 24px;
            color: var(--primary-teal);
        }

        .sidebar-brand h2 {
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex-grow: 1;
        }

        .sidebar-item a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: var(--border-radius);
            transition: var(--transition);
        }

        .sidebar-item a:hover {
            color: var(--white);
            background-color: rgba(255, 255, 255, 0.05);
        }

        .sidebar-item.active a {
            color: var(--white);
            background-color: var(--primary-teal);
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            font-size: 12px;
            color: rgba(255, 255, 255, 0.4);
            text-align: center;
        }

        /* Main Content wrapper */
        .main-wrapper {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        /* Navbar Layout */
        .navbar {
            background-color: var(--white);
            border-bottom: 1px solid var(--border-gray);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-left: auto;
        }

        .user-name {
            font-weight: 600;
            font-size: 14px;
            color: var(--text-dark);
        }

        .btn-header {
            background-color: transparent;
            color: var(--text-dark);
            border: 1px solid var(--border-gray);
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-header:hover {
            background-color: var(--bg-light);
            border-color: var(--text-dark);
        }
    </style>
    <!-- CRM layout styling -->
    <link rel="stylesheet" href="../assets/crm.css">
</head>
<body>

    <!-- Left Sidebar Menu -->
    <aside class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-layer-group"></i>
            <h2>LIMA ERP</h2>
        </div>
        <ul class="sidebar-menu" id="sidebar-menu">
            <li class="sidebar-item">
                <a href="../../admin/index.php"><i class="fa-solid fa-gauge"></i> Dashboard</a>
            </li>
            <li class="sidebar-item active">
                <a href="list.php"><i class="fa-solid fa-users"></i> Clientes</a>
            </li>
            <li class="sidebar-item" id="menu-invoices" style="display: none;">
                <a href="../../facture/"><i class="fa-solid fa-file-invoice-dollar"></i> Factures</a>
            </li>
            <li class="sidebar-item" id="menu-settings" style="display: none;">
                <a href="../../admin/index.php#settings-link"><i class="fa-solid fa-sliders"></i> Configuration</a>
            </li>
        </ul>
        <div class="sidebar-footer">
            <span>&copy; 2026 LIMA Solutions</span>
        </div>
    </aside>

    <!-- Right Content Panel -->
    <div class="main-wrapper">
        <!-- Top Navigation Bar -->
        <header class="navbar">
            <div class="user-menu">
                <span class="user-name" id="user-display-name">...</span>
                <a href="list.php" class="btn-header"><i class="fa-solid fa-arrow-left"></i> Retour</a>
            </div>
        </header>

        <!-- Main CRM Container -->
        <main class="crm-container">
            <!-- Header Row -->
            <div class="crm-header-row">
                <div class="crm-title-section">
                    <h2>Fiche Client: <?php echo htmlspecialchars($client['name']); ?></h2>
                    <p>Profil complet et historique des transactions du client.</p>
                </div>
                <div id="edit-btn-container" style="display: none;">
                    <a href="form.php?id=<?php echo $client['id']; ?>" class="btn-crm btn-crm-primary" style="padding: 10px 20px; font-size: 14px;">
                        <i class="fa-solid fa-pen"></i> Modifier Fiche
                    </a>
                </div>
            </div>

            <!-- Profile Layout Grid -->
            <div class="crm-profile-layout">
                <!-- Sidebar Info Cards -->
                <div class="crm-profile-sidebar">
                    <!-- Avatar Card -->
                    <div class="profile-avatar-card">
                        <div class="profile-avatar"><?php echo $initials; ?></div>
                        <h3 class="profile-name"><?php echo htmlspecialchars($client['name']); ?></h3>
                        <p class="profile-code"><?php echo htmlspecialchars($client['customer_code']); ?></p>
                        
                        <?php if (!empty($client['tags'])): ?>
                            <div style="margin-top: 15px; display: flex; flex-wrap: wrap; justify-content: center; gap: 4px;">
                                <?php foreach(explode(',', $client['tags']) as $tag): ?>
                                    <span class="crm-badge-tag"><?php echo htmlspecialchars(trim($tag)); ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Details Box -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-circle-info"></i> Coordonnées</h3>
                        
                        <div style="display: flex; flex-direction: column; gap: 12px; font-size: 14px;">
                            <?php if (!empty($client['company'])): ?>
                                <div><strong style="color: var(--text-light);">Entreprise:</strong> <br><?php echo htmlspecialchars($client['company']); ?></div>
                            <?php endif; ?>

                            <?php if (!empty($client['contact_person'])): ?>
                                <div><strong style="color: var(--text-light);">Interlocuteur:</strong> <br><?php echo htmlspecialchars($client['contact_person']); ?></div>
                            <?php endif; ?>

                            <div>
                                <strong style="color: var(--text-light);">Téléphones:</strong> <br>
                                <?php if (!empty($client['phone'])): ?>
                                    <i class="fa-solid fa-phone"></i> <?php echo htmlspecialchars($client['phone']); ?><br>
                                <?php endif; ?>
                                <?php if (!empty($client['mobile'])): ?>
                                    <i class="fa-solid fa-mobile"></i> <?php echo htmlspecialchars($client['mobile']); ?><br>
                                <?php endif; ?>
                                <?php if (!empty($client['whatsapp'])): ?>
                                    <i class="fa-brands fa-whatsapp" style="color: #25d366;"></i> <?php echo htmlspecialchars($client['whatsapp']); ?>
                                <?php endif; ?>
                                <?php if (empty($client['phone']) && empty($client['mobile']) && empty($client['whatsapp'])): ?>
                                    -
                                <?php endif; ?>
                            </div>

                            <?php if (!empty($client['email'])): ?>
                                <div><strong style="color: var(--text-light);">E-mail:</strong> <br><i class="fa-solid fa-envelope"></i> <a href="mailto:<?php echo htmlspecialchars($client['email']); ?>" style="color: var(--primary-teal); text-decoration: none;"><?php echo htmlspecialchars($client['email']); ?></a></div>
                            <?php endif; ?>

                            <?php if (!empty($client['website'])): ?>
                                <div><strong style="color: var(--text-light);">Site internet:</strong> <br><i class="fa-solid fa-globe"></i> <a href="http://<?php echo htmlspecialchars($client['website']); ?>" target="_blank" style="color: var(--primary-teal); text-decoration: none;"><?php echo htmlspecialchars($client['website']); ?></a></div>
                            <?php endif; ?>

                            <div>
                                <strong style="color: var(--text-light);">Adresse de facturation:</strong> <br>
                                <?php echo htmlspecialchars($client['address']); ?><br>
                                <?php echo htmlspecialchars($client['postal_code']); ?> <?php echo htmlspecialchars($client['city']); ?><br>
                                <?php echo htmlspecialchars($client['canton'] ?? ''); ?> (<?php echo htmlspecialchars($client['country']); ?>)
                            </div>

                            <?php if (!empty($client['vat_number'])): ?>
                                <div><strong style="color: var(--text-light);">NIF / UID (TVA):</strong> <br><?php echo htmlspecialchars($client['vat_number']); ?></div>
                            <?php endif; ?>

                            <div><strong style="color: var(--text-light);">Langue préférée:</strong> <br><?php echo $client['preferred_language'] === 'FR' ? 'Français' : ($client['preferred_language'] === 'PT' ? 'Português' : 'English'); ?></div>
                        </div>
                    </div>
                </div>

                <!-- Main Section Tabular lists -->
                <div class="crm-profile-main">
                    <!-- Internal Notes -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-pen-nib"></i> Notes internes</h3>
                        <p style="font-size: 14px; line-height: 1.6; white-space: pre-wrap; color: var(--text-dark); background-color: var(--bg-light); padding: 15px; border-radius: var(--border-radius); border: 1px solid var(--border-gray);"><?php echo !empty($client['notes']) ? htmlspecialchars($client['notes']) : 'Aucune note enregistrée sur ce client.'; ?></p>
                    </div>

                    <!-- Total Invoiced Box -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-chart-line"></i> Total facturé</h3>
                        <div style="font-size: 28px; font-weight: 700; color: var(--primary-teal-dark); padding: 10px 0;">
                            0.00 CHF <span style="font-size: 12px; color: var(--text-light); font-weight: 500;">(Placeholder - Connexion au module de factures à venir)</span>
                        </div>
                    </div>

                    <!-- Invoices History -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-file-invoice-dollar"></i> Historique des Factures</h3>
                        <div class="placeholder-box">
                            <i class="fa-solid fa-receipt"></i>
                            <p style="font-size: 14px; font-weight: 500;">Aucune facture liée.</p>
                            <p style="font-size: 12px; color: var(--text-light); margin-top: 4px;">Le module de facturation sera intégré lors de la prochaine phase.</p>
                        </div>
                    </div>

                    <!-- Quotes History -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-calculator"></i> Historique des Devis / Orçamentos</h3>
                        <div class="placeholder-box">
                            <i class="fa-solid fa-file-signature"></i>
                            <p style="font-size: 14px; font-weight: 500;">Aucun devis lié.</p>
                            <p style="font-size: 12px; color: var(--text-light); margin-top: 4px;">Le module de devis sera intégré lors des prochaines phases.</p>
                        </div>
                    </div>

                    <!-- Payments Placeholder -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-wallet"></i> Historique des Paiements</h3>
                        <div class="placeholder-box">
                            <i class="fa-solid fa-money-bill-transfer"></i>
                            <p style="font-size: 14px; font-weight: 500;">Aucun paiement enregistré.</p>
                            <p style="font-size: 12px; color: var(--text-light); margin-top: 4px;">La gestion des transactions financières sera intégrée lors des prochaines phases.</p>
                        </div>
                    </div>

                    <!-- Timeline de atividades Placeholder -->
                    <div class="crm-form-section">
                        <h3 class="crm-form-section-title"><i class="fa-solid fa-clock-rotate-left"></i> Timeline d'Activités (Placeholder)</h3>
                        <div style="font-size: 13px; color: var(--text-dark); display: flex; flex-direction: column; gap: 12px; margin-top: 10px;">
                            <div style="border-left: 2px solid var(--primary-teal); padding-left: 14px; position: relative;">
                                <div style="font-weight: 700; color: var(--primary-teal-dark);">Création du profil client</div>
                                <div style="font-size: 11px; color: var(--text-light);">Par: Système - Date de création du dossier</div>
                            </div>
                            <div style="border-left: 2px solid var(--border-gray); padding-left: 14px; position: relative;">
                                <div style="font-weight: 600; color: var(--text-light);">Aucune interaction récente</div>
                                <div style="font-size: 11px; color: var(--text-light);">L'intégration des e-mails, devis et appels sera configurée ultérieurement.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Notification Toast -->
    <div class="toast" id="toast"></div>

    <script>
        // Check active modules and permissions dynamically for sidebar links
        fetch('../../../api/v1/session.php')
            .then(res => res.json())
            .then(data => {
                if (data.authenticated) {
                    document.getElementById('user-display-name').textContent = data.user.name;
                    
                    // Customize main color
                    if (data.active_company && data.active_company.main_color) {
                        document.documentElement.style.setProperty('--primary-teal', data.active_company.main_color);
                    }

                    // Dynamically toggle sidebar links
                    if (data.enabled_modules.includes('invoices')) {
                        document.getElementById('menu-invoices').style.display = 'block';
                    }
                    if (data.enabled_modules.includes('settings') && (data.user.role === 'super_admin' || data.user.role === 'admin')) {
                        document.getElementById('menu-settings').style.display = 'block';
                    }

                    // Dynamic access check for "Modifier Fiche" button
                    let hasEditPermission = false;
                    if (data.user.role === 'super_admin') {
                        hasEditPermission = true;
                    } else {
                        const perm = data.permissions.find(p => p.module_name === 'crm');
                        hasEditPermission = perm && parseInt(perm.can_edit) === 1;
                    }

                    if (hasEditPermission) {
                        document.getElementById('edit-btn-container').style.display = 'block';
                    }
                } else {
                    window.location.href = '../../admin/login.php';
                }
            })
            .catch(err => {
                console.error(err);
                window.location.href = '../../admin/login.php';
            });
    </script>
</body>
</html>
