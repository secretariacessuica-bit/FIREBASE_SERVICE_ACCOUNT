<?php
// LIMA Solutions ERP - Authentication Middleware
require_once __DIR__ . '/../api/v1/config.php';

// Send hardened HTTP security headers on every protected admin page.
sendSecurityHeaders();

// ─── Authentication Check ────────────────────────────────────────────────────
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// ─── Active Company Validation ───────────────────────────────────────────────
$activeCompanyId = getActiveCompanyId();

if (!$activeCompanyId) {
    $role = $_SESSION['user_role'] ?? 'viewer';

    if ($role === 'super_admin') {
        // Super admins may select a company to impersonate.
        header('Location: select_company.php');
    } else {
        // Regular users without an associated company cannot proceed.
        session_unset();
        session_destroy();
        header('Location: login.php?error=no_company');
    }
    exit();
}
