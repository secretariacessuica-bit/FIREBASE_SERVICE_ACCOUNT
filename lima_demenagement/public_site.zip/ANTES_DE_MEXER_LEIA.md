# ⚠️ ANTES DE MEXER NESTE CÓDIGO, LEIA ESTE GUIA (A BÍBLIA DO DESENVOLVEDOR)

Este documento contém as regras fundamentais de arquitetura, segurança e integridade do **LIMA Solutions ERP**. Qualquer alteração ao código deve respeitar escrupulosamente estas diretrizes para não quebrar o sistema ou expor dados sensíveis.

---

## 1. Regra de Ouro: Isolamento Total
O LIMA Solutions ERP está hospedado no mesmo servidor Infomaniak que outros projetos (como o `cesbulle.ch`), mas deve permanecer **100% isolado**.
* **Ficheiros Públicos**: Estão todos em `/sites/limasolutions.ch/`.
* **Ficheiros Privados (Credenciais)**: Estão em `/sites/private_lima/`. **NUNCA** coloque esta pasta dentro da raiz pública.
* **Base de Dados**: Usa a base de dados dedicada `6o9v7p_erp`. Não partilhe tabelas ou ligações com nenhum outro site.

---

## 2. Estrutura de Diretórios em Produção
```text
/home/clients/c60c25a0672639c5f81740b42f06902c/sites/
├── private_lima/               ← FORA do acesso público via browser
│   ├── config.php              ← Dados de ligação à base de dados (MySQL)
│   └── storage/                ← Armazenamento de faturas (PDF) e recibos
│
└── limasolutions.ch/           ← Pasta raiz pública (onde este ficheiro está)
    ├── admin/                  ← Painel administrativo (login, auditorias, etc.)
    ├── api/v1/                 ← Endpoints de API públicos e privados
    ├── db/                     ← Scripts de migração e o schema.sql
    ├── facture/                ← Visualizador público de faturas para clientes
    ├── helpers/                ← Funções auxiliares (PDF, finanças)
    └── modules/                ← Módulos do sistema (CRM, faturas, projetos, etc.)
```

---

## 3. Segurança e Endurecimento (Hardening)
* **Controle de Erros**: Em produção, `display_errors` está desativado (`Off`). Qualquer erro de PHP é registado no servidor e nunca mostrado ao utilizador.
* **Segurança de Sessões**: As sessões usam `HttpOnly`, `SameSite=Strict` e `cookie_secure` automático (ativado apenas quando acedido via HTTPS).
* **Proteção de Pastas**:
  * O acesso direto a ficheiros `.sql` ou `.php` dentro da pasta `db/` é totalmente bloqueado via `.htaccess`.
  * O ficheiro `seed.php` apaga-se automaticamente após a primeira execução.
* **Ficheiro de Configuração**: O ficheiro público `/api/v1/config.php` apenas serve para ler o caminho seguro `/sites/private_lima/config.php`. Toda a lógica deve depender deste último.

---

## 4. Governança Fiscal e Faturação (Crítico)
Ao alterar os módulos de `timesheets` (folhas de horas) ou `invoices` (faturas), respeite as seguintes regras:
1. **Evitar Dupla Faturação (Concorrência)**:
   * A conversão de folhas de horas em faturas (`convertToInvoice`) usa a instrução `SELECT ... FOR UPDATE` para bloquear as linhas na base de dados durante a transação ativa. Isto previne que dois cliques simultâneos criem duas faturas para as mesmas horas.
2. **Snapshots Financeiros**:
   * O valor faturado baseia-se nos snapshots `approved_billable_rate` (taxa cobrada ao cliente) e `approved_hourly_cost` (custo do funcionário) congelados no momento da aprovação do timesheet. **Nunca** use as taxas ativas do cadastro de clientes/utilizadores para relatórios retroativos.
3. **Regra de Cancelamento**:
   * O cancelamento de uma fatura **nunca** deve apagar o `invoice_id`, o `billing_batch_id` ou os snapshots financeiros, nem desbloquear as folhas de horas. Isto garante a integridade e rastreabilidade para auditorias fiscais.
4. **ID de Lote (`billing_batch_id`)**:
   * Cada operação de faturação em lote gera um UUID v4 único que fica gravado tanto na fatura como nos timesheets faturados.

---

## 5. Migrações de Base de Dados
* As migrações da base de dados **não podem ser executadas via HTTP** (estão bloqueadas por regras do `.htaccess`).
* Devem ser sempre executadas por SSH na linha de comandos:
  ```bash
  php /home/clients/c60c25a0672639c5f81740b42f06902c/sites/limasolutions.ch/db/migrate_v10_1.php
  ```

---

## 6. Contactos de Emergência do Projeto
* **Dono do Alojamento**: LIMA Solutions
* **Domínio Oficial**: `https://limasolutions.ch`
* **Criado em**: Junho de 2026

*Se for um programador ou assistente de IA que acabou de chegar a este projeto: não mude a lógica estrutural sem ler o `docs/ARCHITECTURE.md` e validar o fluxo principal de faturamento.*
