<?php
// LIMA Solutions ERP - Audit Log Helper
// Centralizes all writes to the activity_logs table.

/**
 * Records an audit event in the activity_logs table.
 *
 * @param int         $companyId  Active company scope.
 * @param int         $userId     ID of the user performing the action.
 * @param string      $action     Action key (e.g. 'created', 'approved', 'deleted').
 * @param string      $entity     Entity type (e.g. 'timesheets', 'invoices', 'projects').
 * @param int|null    $entityId   Database ID of the target record (nullable for bulk ops).
 * @param string|null $detail     Optional human-readable description or JSON payload.
 * @param PDO         $pdo        Active PDO connection.
 * @return bool True on success, false if required params missing or insert fails.
 */
function logAuditEvent($companyId, $userId, $action, $entity, $entityId, $detail, $pdo) {
    if (empty($companyId) || empty($userId) || empty($action) || empty($entity)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO activity_logs
                (company_id, user_id, action, entity, entity_id, detail, created_at)
             VALUES
                (:company_id, :user_id, :action, :entity, :entity_id, :detail, NOW())"
        );

        return $stmt->execute([
            'company_id' => (int) $companyId,
            'user_id'    => (int) $userId,
            'action'     => mb_substr(trim($action), 0, 100),
            'entity'     => mb_substr(trim($entity), 0, 100),
            'entity_id'  => $entityId ? (int) $entityId : null,
            'detail'     => $detail ? mb_substr(trim($detail), 0, 2000) : null,
        ]);
    } catch (Exception $e) {
        // Never let an audit failure crash the main request.
        error_log('[LIMA][audit_helper] Failed to log audit event: ' . $e->getMessage());
        return false;
    }
}
