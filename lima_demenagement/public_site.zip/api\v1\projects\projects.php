<?php
// LIMA Solutions ERP - Projects API V1

require_once '../../../admin/auth.php';
require_once '../../../admin/modules_helper.php';
require_once '../../../admin/sequences_helper.php';
require_once '../../../admin/timeline_helper.php';
require_once '../../../admin/audit_helper.php';
require_once '../../../modules/projects/model/Project.php';
require_once '../../../modules/projects/controller/ProjectController.php';

header('Content-Type: application/json; charset=utf-8');

$companyId = getActiveCompanyId();
if (!$companyId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Aucune entreprise active selectionnée.']);
    exit();
}

$userRole = $_SESSION['user_role'] ?? 'viewer';
$userId = $_SESSION['user_id'] ?? 0;

// Enforce Module Access
enforceModuleAccess('projects', $userRole, $companyId, 'view', $pdo);

$projectModel = new Project($pdo);
$controller = new ProjectController($projectModel);

$method = $_SERVER['REQUEST_METHOD'];

// CSRF Protection for mutating requests
if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    $clientCsrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $input['csrf_token'] ?? '';
    $sessionCsrfToken = $_SESSION['csrf_token'] ?? '';

    if (empty($sessionCsrfToken) || empty($clientCsrfToken) || !hash_equals($sessionCsrfToken, $clientCsrfToken)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Erreur de sécurité CSRF: Requête rejetée.']);
        exit();
    }
} else {
    $input = $_GET;
}

if ($method === 'GET') {
    // Determine if getting a task or project
    if (isset($_GET['task_id'])) {
        $taskId = (int)$_GET['task_id'];
        $task = $projectModel->getTaskById($taskId, $companyId);
        if (!$task) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Tâche non trouvée.']);
            exit();
        }
        echo json_encode(['success' => true, 'data' => ['task' => $task]]);
        exit();
    }

    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        $project = $projectModel->getById($id, $companyId);
        if (!$project) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Projet non trouvé.']);
            exit();
        }
        $tasks = $projectModel->getTasks($id, $companyId);
        echo json_encode(['success' => true, 'data' => ['project' => $project, 'tasks' => $tasks]]);
        exit();
    }

    // List projects with pagination & filters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    if ($page < 1) $page = 1;
    if ($limit < 1 || $limit > 200) $limit = 50;
    $offset = ($page - 1) * $limit;

    $filters = [
        'search' => $_GET['search'] ?? '',
        'status' => $_GET['status'] ?? ''
    ];

    $projects = $projectModel->getAll($companyId, $filters, $limit, $offset);
    $total = $projectModel->getTotalCount($companyId, $filters);

    echo json_encode([
        'success' => true,
        'data' => [
            'projects' => $projects,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total_records' => $total,
                'total_pages' => ceil($total / $limit)
            ]
        ]
    ]);
    exit();
}

// Write checks
if (!hasModulePermission($userRole, 'projects', 'edit', $pdo)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => "Accès interdit: Droits d'écriture insuffisants."]);
    exit();
}

if ($method === 'POST') {
    $action = $input['action'] ?? '';

    if ($action === 'create_task') {
        $cleanData = $controller->sanitize($input);
        $errors = $controller->validateTask($cleanData);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }
        try {
            $taskId = $projectModel->createTask($cleanData, $companyId, $userId);
            $newTask = $projectModel->getTaskById($taskId, $companyId);
            $reqId = bin2hex(random_bytes(16));
            logActivity($userId, $companyId, 'projects', 'project_tasks', $taskId, 'Created task: ' . $newTask['task_code'], $pdo, null, $newTask, $reqId);

            echo json_encode(['success' => true, 'message' => 'Tâche créée avec succès.', 'data' => ['id' => $taskId, 'task_code' => $newTask['task_code']]]);
        } catch (Exception $e) {
            http_response_code($e->getCode() === 409 ? 409 : 500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    if ($action === 'update_task') {
        $taskId = (int)($input['id'] ?? 0);
        if (!$taskId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID tâche manquant.']);
            exit();
        }
        $cleanData = $controller->sanitize($input);
        $errors = $controller->validateTask($cleanData);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }
        try {
            $oldTask = $projectModel->getTaskById($taskId, $companyId);
            $projectModel->updateTask($taskId, $cleanData, $companyId, $userId);
            $newTask = $projectModel->getTaskById($taskId, $companyId);
            $reqId = bin2hex(random_bytes(16));
            logActivity($userId, $companyId, 'projects', 'project_tasks', $taskId, 'Updated task: ' . $newTask['task_code'], $pdo, $oldTask, $newTask, $reqId);

            echo json_encode(['success' => true, 'message' => 'Tâche mise à jour avec succès.']);
        } catch (Exception $e) {
            http_response_code($e->getCode() === 409 ? 409 : 500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    if ($action === 'delete_task') {
        $taskId = (int)($input['id'] ?? 0);
        if (!$taskId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID tarefa manquant.']);
            exit();
        }
        try {
            $oldTask = $projectModel->getTaskById($taskId, $companyId);
            $projectModel->softDeleteTask($taskId, $companyId, $userId);
            $reqId = bin2hex(random_bytes(16));
            logActivity($userId, $companyId, 'projects', 'project_tasks', $taskId, 'Soft deleted task: ' . $oldTask['task_code'], $pdo, $oldTask, null, $reqId);

            echo json_encode(['success' => true, 'message' => 'Tâche supprimée avec succès.']);
        } catch (Exception $e) {
            http_response_code($e->getCode() === 409 ? 409 : 500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    if ($action === 'delete') {
        $id = (int)($input['id'] ?? 0);
        if (!$id) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID projet manquant.']);
            exit();
        }
        try {
            $oldProject = $projectModel->getById($id, $companyId);
            $projectModel->softDelete($id, $companyId, $userId);
            $reqId = bin2hex(random_bytes(16));
            logActivity($userId, $companyId, 'projects', 'projects', $id, 'Soft deleted project: ' . $oldProject['project_code'], $pdo, $oldProject, null, $reqId);

            echo json_encode(['success' => true, 'message' => 'Projet supprimé avec succès.']);
        } catch (Exception $e) {
            http_response_code($e->getCode() === 409 ? 409 : 500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    if ($action === 'update') {
        $id = (int)($input['id'] ?? 0);
        if (!$id) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID projet manquant.']);
            exit();
        }
        $cleanData = $controller->sanitize($input);
        $errors = $controller->validateProject($cleanData);
        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
            exit();
        }
        try {
            $oldProject = $projectModel->getById($id, $companyId);
            $projectModel->update($id, $cleanData, $companyId, $userId);
            $newProject = $projectModel->getById($id, $companyId);
            $reqId = bin2hex(random_bytes(16));
            logActivity($userId, $companyId, 'projects', 'projects', $id, 'Updated project: ' . $newProject['project_code'], $pdo, $oldProject, $newProject, $reqId);

            echo json_encode(['success' => true, 'message' => 'Projet mis à jour avec succès.']);
        } catch (Exception $e) {
            http_response_code($e->getCode() === 409 ? 409 : 500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    // Default POST: Create Project
    $cleanData = $controller->sanitize($input);
    $errors = $controller->validateProject($cleanData);
    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
        exit();
    }
    try {
        $projectId = $projectModel->create($cleanData, $companyId, $userId);
        $newProject = $projectModel->getById($projectId, $companyId);
        $reqId = bin2hex(random_bytes(16));
        logActivity($userId, $companyId, 'projects', 'projects', $projectId, 'Created project: ' . $newProject['project_code'], $pdo, null, $newProject, $reqId);

        echo json_encode(['success' => true, 'message' => 'Projet créé avec succès.', 'data' => ['id' => $projectId, 'project_code' => $newProject['project_code']]]);
    } catch (Exception $e) {
        http_response_code($e->getCode() === 409 ? 409 : 500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
